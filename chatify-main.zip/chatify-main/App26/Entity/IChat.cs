﻿namespace App26
{
    public interface IChat
    {
        void OpenChat(EntityPreview entityPreview);
    }
}